﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemSlot : MonoBehaviour {

    [SerializeField] Image Image;

    private Item item;
    public Item Item
    {
        get { return item; }
        set
        {
            item = value;
            if (item == null)
            {
                Image.enabled = false;
            }
            else
            {
                Image.sprite = item.Icon;
                Image.enabled = true;
            }
        }
    }


    private void OnValidate()
    {
        if (Image == null)
        {
            Image = GetComponent<Image>();
        }
    }


}
