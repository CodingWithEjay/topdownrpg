﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayerX : MonoBehaviour {

    public float speed;
    public float stopDistance;
    SpriteRenderer render;
    Animator anim;


    public Transform target;

    void Start () {
        Debug.Log(GameController.control.PlayerHP);
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        render = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();

    }

    // Update is called once per frame
    void Update()
    {
        if (Vector2.Distance(transform.position, target.position) > stopDistance)
        {
            StopCoroutine("DamagePlayer");
            anim.SetBool("Run", true);
            anim.SetBool("Idle", false);
            transform.position = Vector2.MoveTowards(transform.position, new Vector2(target.position.x, transform.position.y), speed * Time.deltaTime);
        }
        else if (Vector2.Distance(transform.position, target.position) <= stopDistance)
        {
            anim.SetBool("Run", false);
            anim.SetBool("Idle", true);
        }
        if (target.position.x > transform.position.x)
        {
            render.flipX = true;
        }
        else if (target.position.x < transform.position.x)
        {
            render.flipX = false;

        }
    }
    IEnumerator DamagePlayer()
    {
        for (int i = 0; i < GameController.control.PlayerHP;)
        {
            GameController.control.EnemyDamageAmount = Random.Range(5, 8);
            GameController.control.PlayerHP = GameController.control.PlayerHP - GameController.control.EnemyDamageAmount;
            Debug.Log(GameController.control.PlayerHP);
            yield return new WaitForSeconds(GameController.control.EnemyReloadTime);
        }
    }


    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.name == "Hitbox")
        {
            StartCoroutine("DamagePlayer");
        }
    }

}
