﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBattleMovement : MonoBehaviour
{

    public float moveSpeed;
    public float jumpForce;
    public bool onGround = true;
    public LayerMask whatIsGround;
    public Transform groundCheck;
    Animator anim;
    SpriteRenderer render;
    public Transform enemy;

    //Player Stats




    Rigidbody2D rigid;

    // Use this for initialization
    void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        render = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        onGround = Physics2D.OverlapPoint(groundCheck.position, whatIsGround);
        if (Input.GetAxisRaw("Horizontal") > 0.5f || Input.GetAxisRaw("Horizontal") < -0.5f)
        {
            transform.Translate(new Vector3(Input.GetAxisRaw("Horizontal") * moveSpeed * Time.deltaTime, 0f, 0f));
        }

        if (Input.GetAxisRaw("Horizontal") > 0)
        {
            anim.SetBool("MoveX", true);
            anim.speed = 1;
        }
        else if (Input.GetAxisRaw("Horizontal") < 0)
        {
            anim.SetBool("MoveX", true);
            anim.speed = 1;
        }
        else
        {
            anim.SetBool("Idle", true);
            anim.SetBool("MoveX", false);
        }

    }

    void Update()
    {
        if (onGround && Input.GetKeyDown("space"))
        {
            rigid.AddForce(new Vector2(0, jumpForce));
            onGround = false;
        } 

        if (enemy.position.x > transform.position.x)
        {
            render.flipX = true;
        }
        else if (enemy.position.x < transform.position.x)
        {
            render.flipX = false;


        }
    }
}
