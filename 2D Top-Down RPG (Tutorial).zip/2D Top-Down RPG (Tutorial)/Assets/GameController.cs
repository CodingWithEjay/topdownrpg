﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

	public static GameController control;

	public bool playerDead;
	public bool inBattle;

    //Player Stats
    public float PlayerHP = 100;
    public float PlayerMaxHP = 100;
    public GameObject PlayerHealthBar;
    public RectTransform PlayerHealthBarT;



    //Enemy Stats
    public int EnemyDamageAmount = Random.Range(5, 8);
    public float EnemyReloadTime = 1.5f;

    private void Start()
    {
        EnemyDamageAmount = Random.Range(5, 8);
    }

    private void Update()
    {
        if (PlayerHP > PlayerMaxHP)
        {
            PlayerHP = PlayerMaxHP;
        }

        PlayerHealthBarT.localScale = new Vector3(PlayerHP / PlayerMaxHP, PlayerHealthBarT.localScale.y, PlayerHealthBarT.localScale.z);


        if (PlayerHP <= PlayerMaxHP / 2 && PlayerHP > PlayerMaxHP / 4)
        {
            PlayerHealthBar.GetComponent<Image>().color = Color.yellow;
        }
        else if (PlayerHP <= PlayerMaxHP / 4)
        {
            PlayerHealthBar.GetComponent<Image>().color = Color.red;
        }


    }


    void OnEnable()
	{
		SceneManager.sceneLoaded += OnSceneLoaded;
	}

	void OnDisable() {
		SceneManager.sceneLoaded -= OnSceneLoaded;
	}

	private void OnSceneLoaded(Scene scene, LoadSceneMode mode) {
		if (scene.name == "Game" && playerDead == true) {
			inBattle = false;

			Destroy (GameObject.Find ("Enemy"));

		}
	}

	void Awake() {
		if (control == null) {
			DontDestroyOnLoad (gameObject);
			control = this;
		} else if (control != this) {
			Destroy (gameObject);
		}

	}

}
